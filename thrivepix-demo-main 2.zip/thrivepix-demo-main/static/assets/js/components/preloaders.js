$(window).on("load", function() {
    setTimeout(function(){
        $('.colony_preloader').fadeOut('slow');
    }, 500);
});